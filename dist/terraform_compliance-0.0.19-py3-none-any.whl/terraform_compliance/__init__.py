from __future__ import absolute_import, division, print_function
import pkg_resources
from terraform_compliance.TerraformValidator import TerraformValidator #noqa

__version__ = pkg_resources.get_distribution('terraform_compliance').version

__all__ = [
]
__title__ = 'terraform_compliance'
__version__ = '0.0.1'
__author__ = 'Will Rubel'
__author_email__ = 'willrubel@gmail.com'

